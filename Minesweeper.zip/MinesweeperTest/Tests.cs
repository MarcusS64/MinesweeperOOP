﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MinesweeperTest;

[TestClass]
public class Tests
{
    [TestMethod]
    public void TestMethod1()
    {
    }
}
